#!/bin/bash
#SBATCH --job-name=preproc_behavior
#SBATCH --output=logs/%x_%A_%a.out   # logs/jobname_jobID_arrayID.out
#SBATCH --time=01:00:00              # adjust as needed
#SBATCH --mem=4G                     # adjust memory as needed
#SBATCH --cpus-per-task=1
#SBATCH --array=1-3
#SBATCH --mail-user=example_username@brown.edu
#SBATCH --mail-type=ALL

# To run this command, type: sbatch run_preprocess_behavior.sh subjects.txt

# ============================
# User configuration
# ============================
BIDS_DIR="/path/to/bids"        # <--- EDIT THIS PATH
SCRIPT="preprocess_behavior.py"      # Python script path

# Make sure logs directory exists
mkdir -p logs

# Get subject for this array task
SUBJ=$(sed -n "${SLURM_ARRAY_TASK_ID}p" subjects.txt)

# Redirect stdout and stderr to log files with subjectID
exec >logs/${SUBJ}_${SLURM_JOB_NAME}_${SLURM_JOB_ID}_${SLURM_ARRAY_TASK_ID}.out \
     2>logs/${SUBJ}_${SLURM_JOB_NAME}_${SLURM_JOB_ID}_${SLURM_ARRAY_TASK_ID}.err

echo "SLURM_ARRAY_TASK_ID: $SLURM_ARRAY_TASK_ID"
echo "Processing subject: $SUBJ"

# ----------------------------------------
# Load anaconda module
# ----------------------------------------
module load anaconda

# Optional: activate base or another conda environment if needed
# source activate base
# OR, if you have a custom env:
# conda activate myenv

# Run the Python script
python $SCRIPT --subj $SUBJ --bids_dir $BIDS_DIR
