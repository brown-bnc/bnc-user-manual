﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2022.2.4),
    on Tue Nov 22 13:43:27 2022
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2022.2.4'
expName = 'LRChx'  # from the Builder filename that created this script
expInfo = {
    'participant': '',
}
# --- Show participant info dialog --
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/elizabethlorenc/Library/Mobile Documents/com~apple~CloudDocs/Documents/Documents - Elizabeth’s MacBook Pro/hemifield_localizer/LRChx_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.DEBUG)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# --- Setup the Window ---
win = visual.Window(
    size=[1920, 1080], fullscr=True, screen=0, 
    winType='pyglet', allowStencil=False,
    monitor='BOLDScreen', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
win.mouseVisible = False
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# --- Setup input devices ---
ioConfig = {}

# Setup iohub keyboard
ioConfig['Keyboard'] = dict(use_keymap='psychopy')

ioSession = '1'
if 'session' in expInfo:
    ioSession = str(expInfo['session'])
ioServer = io.launchHubServer(window=win, **ioConfig)
eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='iohub')

# --- Initialize components for Routine "Init_Code_Routine" ---
# Run 'Begin Experiment' code from Init_Code
LoopsPerBlock = 72
nLRCycles = 6

# --- Initialize components for Routine "waitfortrigger" ---
trigger_signal = keyboard.Keyboard()
trigger_fixation = visual.ShapeStim(
    win=win, name='trigger_fixation', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0), anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='yellow', fillColor='yellow',
    opacity=None, depth=-1.0, interpolate=True)

# --- Initialize components for Routine "LeftChecksA_routine" ---
LeftChecksAStim = visual.ImageStim(
    win=win,
    name='LeftChecksAStim', units='pix', 
    image='lfa_1920.bmp', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1920,1080),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
LChxFixA = visual.ShapeStim(
    win=win, name='LChxFixA', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0), anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=1.0, depth=-2.0, interpolate=True)

# --- Initialize components for Routine "LeftChecksB_routine" ---
LeftChecksBStim = visual.ImageStim(
    win=win,
    name='LeftChecksBStim', units='pix', 
    image='lfb_1920.bmp', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1920,1080),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
LChxFixB = visual.ShapeStim(
    win=win, name='LChxFixB', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0), anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=1.0, depth=-1.0, interpolate=True)

# --- Initialize components for Routine "RightChecksA_routine" ---
RightChecksAStim = visual.ImageStim(
    win=win,
    name='RightChecksAStim', units='pix', 
    image='rfa_1920.bmp', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1920,1080),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
RChxFixA = visual.ShapeStim(
    win=win, name='RChxFixA', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0), anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=1.0, depth=-2.0, interpolate=True)

# --- Initialize components for Routine "RightChecksB_routine" ---
RightChecksBStim = visual.ImageStim(
    win=win,
    name='RightChecksBStim', units='pix', 
    image='rfb_1920.bmp', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1920,1080),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
RChxFixB = visual.ShapeStim(
    win=win, name='RChxFixB', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0), anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=1.0, depth=-1.0, interpolate=True)

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.Clock()  # to track time remaining of each (possibly non-slip) routine 

# --- Prepare to start Routine "Init_Code_Routine" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
# keep track of which components have finished
Init_Code_RoutineComponents = []
for thisComponent in Init_Code_RoutineComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "Init_Code_Routine" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Init_Code_RoutineComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "Init_Code_Routine" ---
for thisComponent in Init_Code_RoutineComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "Init_Code_Routine" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "waitfortrigger" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
trigger_signal.keys = []
trigger_signal.rt = []
_trigger_signal_allKeys = []
# keep track of which components have finished
waitfortriggerComponents = [trigger_signal, trigger_fixation]
for thisComponent in waitfortriggerComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "waitfortrigger" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *trigger_signal* updates
    waitOnFlip = False
    if trigger_signal.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        trigger_signal.frameNStart = frameN  # exact frame index
        trigger_signal.tStart = t  # local t and not account for scr refresh
        trigger_signal.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(trigger_signal, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'trigger_signal.started')
        trigger_signal.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(trigger_signal.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(trigger_signal.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if trigger_signal.status == STARTED and not waitOnFlip:
        theseKeys = trigger_signal.getKeys(keyList=['t'], waitRelease=False)
        _trigger_signal_allKeys.extend(theseKeys)
        if len(_trigger_signal_allKeys):
            trigger_signal.keys = _trigger_signal_allKeys[-1].name  # just the last key pressed
            trigger_signal.rt = _trigger_signal_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *trigger_fixation* updates
    if trigger_fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        trigger_fixation.frameNStart = frameN  # exact frame index
        trigger_fixation.tStart = t  # local t and not account for scr refresh
        trigger_fixation.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(trigger_fixation, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'trigger_fixation.started')
        trigger_fixation.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in waitfortriggerComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "waitfortrigger" ---
for thisComponent in waitfortriggerComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if trigger_signal.keys in ['', [], None]:  # No response was made
    trigger_signal.keys = None
thisExp.addData('trigger_signal.keys',trigger_signal.keys)
if trigger_signal.keys != None:  # we had a response
    thisExp.addData('trigger_signal.rt', trigger_signal.rt)
thisExp.nextEntry()
# Run 'End Routine' code from start_trigger_clock
triggerTimer = core.MonotonicClock()
# the Routine "waitfortrigger" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Block_Loop = data.TrialHandler(nReps=nLRCycles, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=[None],
    seed=None, name='Block_Loop')
thisExp.addLoop(Block_Loop)  # add the loop to the experiment
thisBlock_Loop = Block_Loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlock_Loop.rgb)
if thisBlock_Loop != None:
    for paramName in thisBlock_Loop:
        exec('{} = thisBlock_Loop[paramName]'.format(paramName))

for thisBlock_Loop in Block_Loop:
    currentLoop = Block_Loop
    # abbreviate parameter names if possible (e.g. rgb = thisBlock_Loop.rgb)
    if thisBlock_Loop != None:
        for paramName in thisBlock_Loop:
            exec('{} = thisBlock_Loop[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    Left_Loop = data.TrialHandler(nReps=1.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('fixOpacity.xlsx'),
        seed=None, name='Left_Loop')
    thisExp.addLoop(Left_Loop)  # add the loop to the experiment
    thisLeft_Loop = Left_Loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisLeft_Loop.rgb)
    if thisLeft_Loop != None:
        for paramName in thisLeft_Loop:
            exec('{} = thisLeft_Loop[paramName]'.format(paramName))
    
    for thisLeft_Loop in Left_Loop:
        currentLoop = Left_Loop
        # abbreviate parameter names if possible (e.g. rgb = thisLeft_Loop.rgb)
        if thisLeft_Loop != None:
            for paramName in thisLeft_Loop:
                exec('{} = thisLeft_Loop[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "LeftChecksA_routine" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        # Run 'Begin Routine' code from save_block_time_left
        if Left_Loop.thisTrialN == 0: 
            thisExp.addData('leftBlockStartTime',triggerTimer.getTime(applyZero=True))
        LChxFixA.setOpacity(fixOpacity)
        # keep track of which components have finished
        LeftChecksA_routineComponents = [LeftChecksAStim, LChxFixA]
        for thisComponent in LeftChecksA_routineComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "LeftChecksA_routine" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *LeftChecksAStim* updates
            if LeftChecksAStim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                LeftChecksAStim.frameNStart = frameN  # exact frame index
                LeftChecksAStim.tStart = t  # local t and not account for scr refresh
                LeftChecksAStim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(LeftChecksAStim, 'tStartRefresh')  # time at next scr refresh
                LeftChecksAStim.setAutoDraw(True)
            if LeftChecksAStim.status == STARTED:
                if frameN >= (LeftChecksAStim.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    LeftChecksAStim.tStop = t  # not accounting for scr refresh
                    LeftChecksAStim.frameNStop = frameN  # exact frame index
                    LeftChecksAStim.setAutoDraw(False)
            
            # *LChxFixA* updates
            if LChxFixA.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                LChxFixA.frameNStart = frameN  # exact frame index
                LChxFixA.tStart = t  # local t and not account for scr refresh
                LChxFixA.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(LChxFixA, 'tStartRefresh')  # time at next scr refresh
                LChxFixA.setAutoDraw(True)
            if LChxFixA.status == STARTED:
                if frameN >= (LChxFixA.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    LChxFixA.tStop = t  # not accounting for scr refresh
                    LChxFixA.frameNStop = frameN  # exact frame index
                    LChxFixA.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in LeftChecksA_routineComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "LeftChecksA_routine" ---
        for thisComponent in LeftChecksA_routineComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "LeftChecksA_routine" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "LeftChecksB_routine" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        LChxFixB.setOpacity(fixOpacity)
        # keep track of which components have finished
        LeftChecksB_routineComponents = [LeftChecksBStim, LChxFixB]
        for thisComponent in LeftChecksB_routineComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "LeftChecksB_routine" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *LeftChecksBStim* updates
            if LeftChecksBStim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                LeftChecksBStim.frameNStart = frameN  # exact frame index
                LeftChecksBStim.tStart = t  # local t and not account for scr refresh
                LeftChecksBStim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(LeftChecksBStim, 'tStartRefresh')  # time at next scr refresh
                LeftChecksBStim.setAutoDraw(True)
            if LeftChecksBStim.status == STARTED:
                if frameN >= (LeftChecksBStim.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    LeftChecksBStim.tStop = t  # not accounting for scr refresh
                    LeftChecksBStim.frameNStop = frameN  # exact frame index
                    LeftChecksBStim.setAutoDraw(False)
            
            # *LChxFixB* updates
            if LChxFixB.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                LChxFixB.frameNStart = frameN  # exact frame index
                LChxFixB.tStart = t  # local t and not account for scr refresh
                LChxFixB.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(LChxFixB, 'tStartRefresh')  # time at next scr refresh
                LChxFixB.setAutoDraw(True)
            if LChxFixB.status == STARTED:
                if frameN >= (LChxFixB.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    LChxFixB.tStop = t  # not accounting for scr refresh
                    LChxFixB.frameNStop = frameN  # exact frame index
                    LChxFixB.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in LeftChecksB_routineComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "LeftChecksB_routine" ---
        for thisComponent in LeftChecksB_routineComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "LeftChecksB_routine" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
    # completed 1.0 repeats of 'Left_Loop'
    
    
    # set up handler to look after randomisation of conditions etc
    Right_Loop = data.TrialHandler(nReps=1.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('fixOpacity.xlsx'),
        seed=None, name='Right_Loop')
    thisExp.addLoop(Right_Loop)  # add the loop to the experiment
    thisRight_Loop = Right_Loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisRight_Loop.rgb)
    if thisRight_Loop != None:
        for paramName in thisRight_Loop:
            exec('{} = thisRight_Loop[paramName]'.format(paramName))
    
    for thisRight_Loop in Right_Loop:
        currentLoop = Right_Loop
        # abbreviate parameter names if possible (e.g. rgb = thisRight_Loop.rgb)
        if thisRight_Loop != None:
            for paramName in thisRight_Loop:
                exec('{} = thisRight_Loop[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "RightChecksA_routine" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        # Run 'Begin Routine' code from save_block_time_right
        if Right_Loop.thisTrialN == 0: 
            thisExp.addData('rightBlockStartTime',triggerTimer.getTime(applyZero=True))
        RChxFixA.setOpacity(fixOpacity)
        # keep track of which components have finished
        RightChecksA_routineComponents = [RightChecksAStim, RChxFixA]
        for thisComponent in RightChecksA_routineComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RightChecksA_routine" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *RightChecksAStim* updates
            if RightChecksAStim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                RightChecksAStim.frameNStart = frameN  # exact frame index
                RightChecksAStim.tStart = t  # local t and not account for scr refresh
                RightChecksAStim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(RightChecksAStim, 'tStartRefresh')  # time at next scr refresh
                RightChecksAStim.setAutoDraw(True)
            if RightChecksAStim.status == STARTED:
                if frameN >= (RightChecksAStim.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    RightChecksAStim.tStop = t  # not accounting for scr refresh
                    RightChecksAStim.frameNStop = frameN  # exact frame index
                    RightChecksAStim.setAutoDraw(False)
            
            # *RChxFixA* updates
            if RChxFixA.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                RChxFixA.frameNStart = frameN  # exact frame index
                RChxFixA.tStart = t  # local t and not account for scr refresh
                RChxFixA.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(RChxFixA, 'tStartRefresh')  # time at next scr refresh
                RChxFixA.setAutoDraw(True)
            if RChxFixA.status == STARTED:
                if frameN >= (RChxFixA.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    RChxFixA.tStop = t  # not accounting for scr refresh
                    RChxFixA.frameNStop = frameN  # exact frame index
                    RChxFixA.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RightChecksA_routineComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RightChecksA_routine" ---
        for thisComponent in RightChecksA_routineComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "RightChecksA_routine" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "RightChecksB_routine" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        RChxFixB.setOpacity(fixOpacity)
        # keep track of which components have finished
        RightChecksB_routineComponents = [RightChecksBStim, RChxFixB]
        for thisComponent in RightChecksB_routineComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RightChecksB_routine" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *RightChecksBStim* updates
            if RightChecksBStim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                RightChecksBStim.frameNStart = frameN  # exact frame index
                RightChecksBStim.tStart = t  # local t and not account for scr refresh
                RightChecksBStim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(RightChecksBStim, 'tStartRefresh')  # time at next scr refresh
                RightChecksBStim.setAutoDraw(True)
            if RightChecksBStim.status == STARTED:
                if frameN >= (RightChecksBStim.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    RightChecksBStim.tStop = t  # not accounting for scr refresh
                    RightChecksBStim.frameNStop = frameN  # exact frame index
                    RightChecksBStim.setAutoDraw(False)
            
            # *RChxFixB* updates
            if RChxFixB.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                RChxFixB.frameNStart = frameN  # exact frame index
                RChxFixB.tStart = t  # local t and not account for scr refresh
                RChxFixB.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(RChxFixB, 'tStartRefresh')  # time at next scr refresh
                RChxFixB.setAutoDraw(True)
            if RChxFixB.status == STARTED:
                if frameN >= (RChxFixB.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    RChxFixB.tStop = t  # not accounting for scr refresh
                    RChxFixB.frameNStop = frameN  # exact frame index
                    RChxFixB.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RightChecksB_routineComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RightChecksB_routine" ---
        for thisComponent in RightChecksB_routineComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "RightChecksB_routine" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
    # completed 1.0 repeats of 'Right_Loop'
    
    thisExp.nextEntry()
    
# completed nLRCycles repeats of 'Block_Loop'


# --- End experiment ---
# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
