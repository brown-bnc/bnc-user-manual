﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.1.4),
    on Tue May 18 12:44:10 2021
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.1.4'
expName = 'LRChx'  # from the Builder filename that created this script
expInfo = {'participant': ''}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/mworden/Documents/Python/psychopy/dev/LRChx/LRChx.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.DEBUG)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[2560, 1440], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='BOLDScreen', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "waitfortrigger"
waitfortriggerClock = core.Clock()
trigger_signal = keyboard.Keyboard()
trigger_fixation = visual.ShapeStim(
    win=win, name='trigger_fixation', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='yellow', fillColor='yellow',
    opacity=None, depth=-1.0, interpolate=True)
LoopsPerBlock = 72
nLRCycles = 6

# Initialize components for Routine "justfixation"
justfixationClock = core.Clock()
fixation_cross = visual.ShapeStim(
    win=win, name='fixation_cross', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=None, depth=0.0, interpolate=True)

# Initialize components for Routine "LeftChecksA_routine"
LeftChecksA_routineClock = core.Clock()
LeftChecksAStim = visual.ImageStim(
    win=win,
    name='LeftChecksAStim', units='pix', 
    image='lfa_1920.bmp', mask=None,
    ori=0.0, pos=(0, 0), size=(1920,1024),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
LChxFixA = visual.ShapeStim(
    win=win, name='LChxFixA', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=None, depth=-1.0, interpolate=True)

# Initialize components for Routine "LeftChecksB_routine"
LeftChecksB_routineClock = core.Clock()
LeftChecksBStim = visual.ImageStim(
    win=win,
    name='LeftChecksBStim', units='pix', 
    image='lfb_1920.bmp', mask=None,
    ori=0.0, pos=(0, 0), size=(1920,1024),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
LChxFixB = visual.ShapeStim(
    win=win, name='LChxFixB', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=None, depth=-1.0, interpolate=True)

# Initialize components for Routine "RightChecksA_routine"
RightChecksA_routineClock = core.Clock()
RightChecksAStim = visual.ImageStim(
    win=win,
    name='RightChecksAStim', units='pix', 
    image='rfa_1920.bmp', mask=None,
    ori=0.0, pos=(0, 0), size=(1920,1024),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
LChxFixA_2 = visual.ShapeStim(
    win=win, name='LChxFixA_2', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=None, depth=-1.0, interpolate=True)

# Initialize components for Routine "RightChecksB_routine"
RightChecksB_routineClock = core.Clock()
RightChecksBStim = visual.ImageStim(
    win=win,
    name='RightChecksBStim', units='pix', 
    image='rfb_1920.bmp', mask=None,
    ori=0.0, pos=(0, 0), size=(1920,1024),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
LChxFixB_2 = visual.ShapeStim(
    win=win, name='LChxFixB_2', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=None, depth=-1.0, interpolate=True)

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "waitfortrigger"-------
continueRoutine = True
# update component parameters for each repeat
trigger_signal.keys = []
trigger_signal.rt = []
_trigger_signal_allKeys = []
# keep track of which components have finished
waitfortriggerComponents = [trigger_signal, trigger_fixation]
for thisComponent in waitfortriggerComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
waitfortriggerClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "waitfortrigger"-------
while continueRoutine:
    # get current time
    t = waitfortriggerClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=waitfortriggerClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *trigger_signal* updates
    waitOnFlip = False
    if trigger_signal.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        trigger_signal.frameNStart = frameN  # exact frame index
        trigger_signal.tStart = t  # local t and not account for scr refresh
        trigger_signal.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(trigger_signal, 'tStartRefresh')  # time at next scr refresh
        trigger_signal.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(trigger_signal.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(trigger_signal.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if trigger_signal.status == STARTED and not waitOnFlip:
        theseKeys = trigger_signal.getKeys(keyList=['t'], waitRelease=False)
        _trigger_signal_allKeys.extend(theseKeys)
        if len(_trigger_signal_allKeys):
            trigger_signal.keys = _trigger_signal_allKeys[-1].name  # just the last key pressed
            trigger_signal.rt = _trigger_signal_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *trigger_fixation* updates
    if trigger_fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        trigger_fixation.frameNStart = frameN  # exact frame index
        trigger_fixation.tStart = t  # local t and not account for scr refresh
        trigger_fixation.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(trigger_fixation, 'tStartRefresh')  # time at next scr refresh
        trigger_fixation.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in waitfortriggerComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "waitfortrigger"-------
for thisComponent in waitfortriggerComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if trigger_signal.keys in ['', [], None]:  # No response was made
    trigger_signal.keys = None
thisExp.addData('trigger_signal.keys',trigger_signal.keys)
if trigger_signal.keys != None:  # we had a response
    thisExp.addData('trigger_signal.rt', trigger_signal.rt)
thisExp.addData('trigger_signal.started', trigger_signal.tStartRefresh)
thisExp.addData('trigger_signal.stopped', trigger_signal.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('trigger_fixation.started', trigger_fixation.tStartRefresh)
thisExp.addData('trigger_fixation.stopped', trigger_fixation.tStopRefresh)
# the Routine "waitfortrigger" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "justfixation"-------
continueRoutine = True
routineTimer.add(12.000000)
# update component parameters for each repeat
# keep track of which components have finished
justfixationComponents = [fixation_cross]
for thisComponent in justfixationComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
justfixationClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "justfixation"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = justfixationClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=justfixationClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *fixation_cross* updates
    if fixation_cross.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        fixation_cross.frameNStart = frameN  # exact frame index
        fixation_cross.tStart = t  # local t and not account for scr refresh
        fixation_cross.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(fixation_cross, 'tStartRefresh')  # time at next scr refresh
        fixation_cross.setAutoDraw(True)
    if fixation_cross.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > fixation_cross.tStartRefresh + 12.0-frameTolerance:
            # keep track of stop time/frame for later
            fixation_cross.tStop = t  # not accounting for scr refresh
            fixation_cross.frameNStop = frameN  # exact frame index
            win.timeOnFlip(fixation_cross, 'tStopRefresh')  # time at next scr refresh
            fixation_cross.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in justfixationComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "justfixation"-------
for thisComponent in justfixationComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('fixation_cross.started', fixation_cross.tStartRefresh)
thisExp.addData('fixation_cross.stopped', fixation_cross.tStopRefresh)

# set up handler to look after randomisation of conditions etc
Block_Loop = data.TrialHandler(nReps=nLRCycles, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=[None],
    seed=None, name='Block_Loop')
thisExp.addLoop(Block_Loop)  # add the loop to the experiment
thisBlock_Loop = Block_Loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlock_Loop.rgb)
if thisBlock_Loop != None:
    for paramName in thisBlock_Loop:
        exec('{} = thisBlock_Loop[paramName]'.format(paramName))

for thisBlock_Loop in Block_Loop:
    currentLoop = Block_Loop
    # abbreviate parameter names if possible (e.g. rgb = thisBlock_Loop.rgb)
    if thisBlock_Loop != None:
        for paramName in thisBlock_Loop:
            exec('{} = thisBlock_Loop[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    Left_Loop = data.TrialHandler(nReps=LoopsPerBlock, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='Left_Loop')
    thisExp.addLoop(Left_Loop)  # add the loop to the experiment
    thisLeft_Loop = Left_Loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisLeft_Loop.rgb)
    if thisLeft_Loop != None:
        for paramName in thisLeft_Loop:
            exec('{} = thisLeft_Loop[paramName]'.format(paramName))
    
    for thisLeft_Loop in Left_Loop:
        currentLoop = Left_Loop
        # abbreviate parameter names if possible (e.g. rgb = thisLeft_Loop.rgb)
        if thisLeft_Loop != None:
            for paramName in thisLeft_Loop:
                exec('{} = thisLeft_Loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "LeftChecksA_routine"-------
        continueRoutine = True
        # update component parameters for each repeat
        # keep track of which components have finished
        LeftChecksA_routineComponents = [LeftChecksAStim, LChxFixA]
        for thisComponent in LeftChecksA_routineComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        LeftChecksA_routineClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "LeftChecksA_routine"-------
        while continueRoutine:
            # get current time
            t = LeftChecksA_routineClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=LeftChecksA_routineClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *LeftChecksAStim* updates
            if LeftChecksAStim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                LeftChecksAStim.frameNStart = frameN  # exact frame index
                LeftChecksAStim.tStart = t  # local t and not account for scr refresh
                LeftChecksAStim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(LeftChecksAStim, 'tStartRefresh')  # time at next scr refresh
                LeftChecksAStim.setAutoDraw(True)
            if LeftChecksAStim.status == STARTED:
                if frameN >= (LeftChecksAStim.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    LeftChecksAStim.tStop = t  # not accounting for scr refresh
                    LeftChecksAStim.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(LeftChecksAStim, 'tStopRefresh')  # time at next scr refresh
                    LeftChecksAStim.setAutoDraw(False)
            
            # *LChxFixA* updates
            if LChxFixA.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                LChxFixA.frameNStart = frameN  # exact frame index
                LChxFixA.tStart = t  # local t and not account for scr refresh
                LChxFixA.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(LChxFixA, 'tStartRefresh')  # time at next scr refresh
                LChxFixA.setAutoDraw(True)
            if LChxFixA.status == STARTED:
                if frameN >= (LChxFixA.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    LChxFixA.tStop = t  # not accounting for scr refresh
                    LChxFixA.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(LChxFixA, 'tStopRefresh')  # time at next scr refresh
                    LChxFixA.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in LeftChecksA_routineComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "LeftChecksA_routine"-------
        for thisComponent in LeftChecksA_routineComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('LChxFixA.started', LChxFixA.tStartRefresh)
        thisExp.addData('LChxFixA.stopped', LChxFixA.tStopRefresh)
        # the Routine "LeftChecksA_routine" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "LeftChecksB_routine"-------
        continueRoutine = True
        # update component parameters for each repeat
        # keep track of which components have finished
        LeftChecksB_routineComponents = [LeftChecksBStim, LChxFixB]
        for thisComponent in LeftChecksB_routineComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        LeftChecksB_routineClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "LeftChecksB_routine"-------
        while continueRoutine:
            # get current time
            t = LeftChecksB_routineClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=LeftChecksB_routineClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *LeftChecksBStim* updates
            if LeftChecksBStim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                LeftChecksBStim.frameNStart = frameN  # exact frame index
                LeftChecksBStim.tStart = t  # local t and not account for scr refresh
                LeftChecksBStim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(LeftChecksBStim, 'tStartRefresh')  # time at next scr refresh
                LeftChecksBStim.setAutoDraw(True)
            if LeftChecksBStim.status == STARTED:
                if frameN >= (LeftChecksBStim.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    LeftChecksBStim.tStop = t  # not accounting for scr refresh
                    LeftChecksBStim.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(LeftChecksBStim, 'tStopRefresh')  # time at next scr refresh
                    LeftChecksBStim.setAutoDraw(False)
            
            # *LChxFixB* updates
            if LChxFixB.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                LChxFixB.frameNStart = frameN  # exact frame index
                LChxFixB.tStart = t  # local t and not account for scr refresh
                LChxFixB.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(LChxFixB, 'tStartRefresh')  # time at next scr refresh
                LChxFixB.setAutoDraw(True)
            if LChxFixB.status == STARTED:
                if frameN >= (LChxFixB.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    LChxFixB.tStop = t  # not accounting for scr refresh
                    LChxFixB.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(LChxFixB, 'tStopRefresh')  # time at next scr refresh
                    LChxFixB.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in LeftChecksB_routineComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "LeftChecksB_routine"-------
        for thisComponent in LeftChecksB_routineComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        Left_Loop.addData('LeftChecksBStim.started', LeftChecksBStim.tStartRefresh)
        Left_Loop.addData('LeftChecksBStim.stopped', LeftChecksBStim.tStopRefresh)
        Left_Loop.addData('LChxFixB.started', LChxFixB.tStartRefresh)
        Left_Loop.addData('LChxFixB.stopped', LChxFixB.tStopRefresh)
        # the Routine "LeftChecksB_routine" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed LoopsPerBlock repeats of 'Left_Loop'
    
    
    # set up handler to look after randomisation of conditions etc
    Right_Loop = data.TrialHandler(nReps=LoopsPerBlock, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='Right_Loop')
    thisExp.addLoop(Right_Loop)  # add the loop to the experiment
    thisRight_Loop = Right_Loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisRight_Loop.rgb)
    if thisRight_Loop != None:
        for paramName in thisRight_Loop:
            exec('{} = thisRight_Loop[paramName]'.format(paramName))
    
    for thisRight_Loop in Right_Loop:
        currentLoop = Right_Loop
        # abbreviate parameter names if possible (e.g. rgb = thisRight_Loop.rgb)
        if thisRight_Loop != None:
            for paramName in thisRight_Loop:
                exec('{} = thisRight_Loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "RightChecksA_routine"-------
        continueRoutine = True
        # update component parameters for each repeat
        # keep track of which components have finished
        RightChecksA_routineComponents = [RightChecksAStim, LChxFixA_2]
        for thisComponent in RightChecksA_routineComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        RightChecksA_routineClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "RightChecksA_routine"-------
        while continueRoutine:
            # get current time
            t = RightChecksA_routineClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=RightChecksA_routineClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *RightChecksAStim* updates
            if RightChecksAStim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                RightChecksAStim.frameNStart = frameN  # exact frame index
                RightChecksAStim.tStart = t  # local t and not account for scr refresh
                RightChecksAStim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(RightChecksAStim, 'tStartRefresh')  # time at next scr refresh
                RightChecksAStim.setAutoDraw(True)
            if RightChecksAStim.status == STARTED:
                if frameN >= (RightChecksAStim.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    RightChecksAStim.tStop = t  # not accounting for scr refresh
                    RightChecksAStim.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(RightChecksAStim, 'tStopRefresh')  # time at next scr refresh
                    RightChecksAStim.setAutoDraw(False)
            
            # *LChxFixA_2* updates
            if LChxFixA_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                LChxFixA_2.frameNStart = frameN  # exact frame index
                LChxFixA_2.tStart = t  # local t and not account for scr refresh
                LChxFixA_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(LChxFixA_2, 'tStartRefresh')  # time at next scr refresh
                LChxFixA_2.setAutoDraw(True)
            if LChxFixA_2.status == STARTED:
                if frameN >= (LChxFixA_2.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    LChxFixA_2.tStop = t  # not accounting for scr refresh
                    LChxFixA_2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(LChxFixA_2, 'tStopRefresh')  # time at next scr refresh
                    LChxFixA_2.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RightChecksA_routineComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "RightChecksA_routine"-------
        for thisComponent in RightChecksA_routineComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('LChxFixA_2.started', LChxFixA_2.tStartRefresh)
        thisExp.addData('LChxFixA_2.stopped', LChxFixA_2.tStopRefresh)
        # the Routine "RightChecksA_routine" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "RightChecksB_routine"-------
        continueRoutine = True
        # update component parameters for each repeat
        # keep track of which components have finished
        RightChecksB_routineComponents = [RightChecksBStim, LChxFixB_2]
        for thisComponent in RightChecksB_routineComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        RightChecksB_routineClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "RightChecksB_routine"-------
        while continueRoutine:
            # get current time
            t = RightChecksB_routineClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=RightChecksB_routineClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *RightChecksBStim* updates
            if RightChecksBStim.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                RightChecksBStim.frameNStart = frameN  # exact frame index
                RightChecksBStim.tStart = t  # local t and not account for scr refresh
                RightChecksBStim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(RightChecksBStim, 'tStartRefresh')  # time at next scr refresh
                RightChecksBStim.setAutoDraw(True)
            if RightChecksBStim.status == STARTED:
                if frameN >= (RightChecksBStim.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    RightChecksBStim.tStop = t  # not accounting for scr refresh
                    RightChecksBStim.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(RightChecksBStim, 'tStopRefresh')  # time at next scr refresh
                    RightChecksBStim.setAutoDraw(False)
            
            # *LChxFixB_2* updates
            if LChxFixB_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                LChxFixB_2.frameNStart = frameN  # exact frame index
                LChxFixB_2.tStart = t  # local t and not account for scr refresh
                LChxFixB_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(LChxFixB_2, 'tStartRefresh')  # time at next scr refresh
                LChxFixB_2.setAutoDraw(True)
            if LChxFixB_2.status == STARTED:
                if frameN >= (LChxFixB_2.frameNStart + 5.0):
                    # keep track of stop time/frame for later
                    LChxFixB_2.tStop = t  # not accounting for scr refresh
                    LChxFixB_2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(LChxFixB_2, 'tStopRefresh')  # time at next scr refresh
                    LChxFixB_2.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RightChecksB_routineComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "RightChecksB_routine"-------
        for thisComponent in RightChecksB_routineComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RightChecksBStim.started', RightChecksBStim.tStartRefresh)
        thisExp.addData('RightChecksBStim.stopped', RightChecksBStim.tStopRefresh)
        thisExp.addData('LChxFixB_2.started', LChxFixB_2.tStartRefresh)
        thisExp.addData('LChxFixB_2.stopped', LChxFixB_2.tStopRefresh)
        # the Routine "RightChecksB_routine" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed LoopsPerBlock repeats of 'Right_Loop'
    
    thisExp.nextEntry()
    
# completed nLRCycles repeats of 'Block_Loop'


# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
