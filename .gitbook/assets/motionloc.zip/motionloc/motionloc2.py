﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.1.4),
    on Mon May 17 15:56:28 2021
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

dotcount=200
stimdur=1


# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.1.4'
expName = 'motionloc2'  # from the Builder filename that created this script
expInfo = {'participant': '47'}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/mworden/Documents/Python/psychopy/dev/motionloc/motionloc2.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.DEBUG)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[2560, 1440], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "waitfortrigger"
waitfortriggerClock = core.Clock()
trigger_signal = keyboard.Keyboard()
trigger_fixation = visual.ShapeStim(
    win=win, name='trigger_fixation', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='yellow', fillColor='yellow',
    opacity=None, depth=-1.0, interpolate=True)

# Initialize components for Routine "justfixation"
justfixationClock = core.Clock()
fixation_cross = visual.ShapeStim(
    win=win, name='fixation_cross', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=None, depth=0.0, interpolate=True)

# Initialize components for Routine "staticdots"
staticdotsClock = core.Clock()
Static_Fix = visual.ShapeStim(
    win=win, name='Static_Fix', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=None, depth=0.0, interpolate=True)
dots_3 = visual.DotStim(
    win=win, name='dots_3',
    nDots=dotcount, dotSize=10.0,
    speed=0.0, dir=0.0, coherence=1.0,
    fieldPos=(0.0, 0.0), fieldSize=1.0,fieldShape='circle',
    signalDots='same', noiseDots='direction',dotLife=-3.0,
    color=[1.0,1.0,1.0], colorSpace='rgb', opacity=1.0,
    depth=-1.0)

# Initialize components for Routine "movingdots"
movingdotsClock = core.Clock()
dots = visual.DotStim(
    win=win, name='dots',
    nDots=dotcount, dotSize=10.0,
    speed=0.01, dir=1.0, coherence=1.0,
    fieldPos=(0.0, 0.0), fieldSize=1.0,fieldShape='circle',
    signalDots='same', noiseDots='direction',dotLife=-1.0,
    color=[1.0,1.0,1.0], colorSpace='rgb', opacity=1.0,
    depth=0.0)
ndots = 100
Moving_Fix = visual.ShapeStim(
    win=win, name='Moving_Fix', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=None, depth=-2.0, interpolate=True)

# Initialize components for Routine "flickeringdots"
flickeringdotsClock = core.Clock()
dots_2 = visual.DotStim(
    win=win, name='dots_2',
    nDots=dotcount, dotSize=10.0,
    speed=0.0, dir=0.0, coherence=1.0,
    fieldPos=(0.0, 0.0), fieldSize=1.0,fieldShape='circle',
    signalDots='same', noiseDots='position',dotLife=5.0,
    color=[1.0,1.0,1.0], colorSpace='rgb', opacity=1.0,
    depth=0.0)
Flicker_Fix = visual.ShapeStim(
    win=win, name='Flicker_Fix', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=None, depth=-1.0, interpolate=True)

# Initialize components for Routine "justfixation"
justfixationClock = core.Clock()
fixation_cross = visual.ShapeStim(
    win=win, name='fixation_cross', vertices='cross',
    size=(0.01, 0.01),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='red', fillColor='red',
    opacity=None, depth=0.0, interpolate=True)

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "waitfortrigger"-------
continueRoutine = True
# update component parameters for each repeat
trigger_signal.keys = []
trigger_signal.rt = []
_trigger_signal_allKeys = []
# keep track of which components have finished
waitfortriggerComponents = [trigger_signal, trigger_fixation]
for thisComponent in waitfortriggerComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
waitfortriggerClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "waitfortrigger"-------
while continueRoutine:
    # get current time
    t = waitfortriggerClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=waitfortriggerClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *trigger_signal* updates
    waitOnFlip = False
    if trigger_signal.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        trigger_signal.frameNStart = frameN  # exact frame index
        trigger_signal.tStart = t  # local t and not account for scr refresh
        trigger_signal.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(trigger_signal, 'tStartRefresh')  # time at next scr refresh
        trigger_signal.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(trigger_signal.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(trigger_signal.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if trigger_signal.status == STARTED and not waitOnFlip:
        theseKeys = trigger_signal.getKeys(keyList=['t'], waitRelease=False)
        _trigger_signal_allKeys.extend(theseKeys)
        if len(_trigger_signal_allKeys):
            trigger_signal.keys = _trigger_signal_allKeys[-1].name  # just the last key pressed
            trigger_signal.rt = _trigger_signal_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *trigger_fixation* updates
    if trigger_fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        trigger_fixation.frameNStart = frameN  # exact frame index
        trigger_fixation.tStart = t  # local t and not account for scr refresh
        trigger_fixation.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(trigger_fixation, 'tStartRefresh')  # time at next scr refresh
        trigger_fixation.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in waitfortriggerComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "waitfortrigger"-------
for thisComponent in waitfortriggerComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if trigger_signal.keys in ['', [], None]:  # No response was made
    trigger_signal.keys = None
thisExp.addData('trigger_signal.keys',trigger_signal.keys)
if trigger_signal.keys != None:  # we had a response
    thisExp.addData('trigger_signal.rt', trigger_signal.rt)
thisExp.addData('trigger_signal.started', trigger_signal.tStartRefresh)
thisExp.addData('trigger_signal.stopped', trigger_signal.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('trigger_fixation.started', trigger_fixation.tStartRefresh)
thisExp.addData('trigger_fixation.stopped', trigger_fixation.tStopRefresh)
# the Routine "waitfortrigger" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "justfixation"-------
continueRoutine = True
routineTimer.add(15.000000)
# update component parameters for each repeat
# keep track of which components have finished
justfixationComponents = [fixation_cross]
for thisComponent in justfixationComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
justfixationClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "justfixation"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = justfixationClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=justfixationClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *fixation_cross* updates
    if fixation_cross.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        fixation_cross.frameNStart = frameN  # exact frame index
        fixation_cross.tStart = t  # local t and not account for scr refresh
        fixation_cross.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(fixation_cross, 'tStartRefresh')  # time at next scr refresh
        fixation_cross.setAutoDraw(True)
    if fixation_cross.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > fixation_cross.tStartRefresh + 15.0-frameTolerance:
            # keep track of stop time/frame for later
            fixation_cross.tStop = t  # not accounting for scr refresh
            fixation_cross.frameNStop = frameN  # exact frame index
            win.timeOnFlip(fixation_cross, 'tStopRefresh')  # time at next scr refresh
            fixation_cross.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in justfixationComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "justfixation"-------
for thisComponent in justfixationComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('fixation_cross.started', fixation_cross.tStartRefresh)
thisExp.addData('fixation_cross.stopped', fixation_cross.tStopRefresh)

# set up handler to look after randomisation of conditions etc
Block_Loop = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('blockpicker.xlsx'),
    seed=None, name='Block_Loop')
thisExp.addLoop(Block_Loop)  # add the loop to the experiment
thisBlock_Loop = Block_Loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlock_Loop.rgb)
if thisBlock_Loop != None:
    for paramName in thisBlock_Loop:
        exec('{} = thisBlock_Loop[paramName]'.format(paramName))

for thisBlock_Loop in Block_Loop:
    currentLoop = Block_Loop
    # abbreviate parameter names if possible (e.g. rgb = thisBlock_Loop.rgb)
    if thisBlock_Loop != None:
        for paramName in thisBlock_Loop:
            exec('{} = thisBlock_Loop[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    Static_Loop = data.TrialHandler(nReps=static_rep, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='Static_Loop')
    thisExp.addLoop(Static_Loop)  # add the loop to the experiment
    thisStatic_Loop = Static_Loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisStatic_Loop.rgb)
    if thisStatic_Loop != None:
        for paramName in thisStatic_Loop:
            exec('{} = thisStatic_Loop[paramName]'.format(paramName))
    
    for thisStatic_Loop in Static_Loop:
        currentLoop = Static_Loop
        # abbreviate parameter names if possible (e.g. rgb = thisStatic_Loop.rgb)
        if thisStatic_Loop != None:
            for paramName in thisStatic_Loop:
                exec('{} = thisStatic_Loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "staticdots"-------
        continueRoutine = True
        routineTimer.add(15.000000)
        # update component parameters for each repeat
        dots_3.refreshDots()
        # keep track of which components have finished
        staticdotsComponents = [Static_Fix, dots_3]
        for thisComponent in staticdotsComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        staticdotsClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "staticdots"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = staticdotsClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=staticdotsClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *Static_Fix* updates
            if Static_Fix.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Static_Fix.frameNStart = frameN  # exact frame index
                Static_Fix.tStart = t  # local t and not account for scr refresh
                Static_Fix.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Static_Fix, 'tStartRefresh')  # time at next scr refresh
                Static_Fix.setAutoDraw(True)
            if Static_Fix.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > Static_Fix.tStartRefresh + 15.0-frameTolerance:
                    # keep track of stop time/frame for later
                    Static_Fix.tStop = t  # not accounting for scr refresh
                    Static_Fix.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(Static_Fix, 'tStopRefresh')  # time at next scr refresh
                    Static_Fix.setAutoDraw(False)
            
            # *dots_3* updates
            if dots_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                dots_3.frameNStart = frameN  # exact frame index
                dots_3.tStart = t  # local t and not account for scr refresh
                dots_3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(dots_3, 'tStartRefresh')  # time at next scr refresh
                dots_3.setAutoDraw(True)
            if dots_3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > dots_3.tStartRefresh + 15.0-frameTolerance:
                    # keep track of stop time/frame for later
                    dots_3.tStop = t  # not accounting for scr refresh
                    dots_3.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(dots_3, 'tStopRefresh')  # time at next scr refresh
                    dots_3.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in staticdotsComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "staticdots"-------
        for thisComponent in staticdotsComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        Static_Loop.addData('Static_Fix.started', Static_Fix.tStartRefresh)
        Static_Loop.addData('Static_Fix.stopped', Static_Fix.tStopRefresh)
        thisExp.nextEntry()
        
    # completed static_rep repeats of 'Static_Loop'
    
    # get names of stimulus parameters
    if Static_Loop.trialList in ([], [None], None):
        params = []
    else:
        params = Static_Loop.trialList[0].keys()
    # save data for this loop
    Static_Loop.saveAsExcel(filename + '.xlsx', sheetName='Static_Loop',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # set up handler to look after randomisation of conditions etc
    Moving_Loop = data.TrialHandler(nReps=moving_rep, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('dot_directions.xlsx'),
        seed=None, name='Moving_Loop')
    thisExp.addLoop(Moving_Loop)  # add the loop to the experiment
    thisMoving_Loop = Moving_Loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisMoving_Loop.rgb)
    if thisMoving_Loop != None:
        for paramName in thisMoving_Loop:
            exec('{} = thisMoving_Loop[paramName]'.format(paramName))
    
    for thisMoving_Loop in Moving_Loop:
        currentLoop = Moving_Loop
        # abbreviate parameter names if possible (e.g. rgb = thisMoving_Loop.rgb)
        if thisMoving_Loop != None:
            for paramName in thisMoving_Loop:
                exec('{} = thisMoving_Loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "movingdots"-------
        continueRoutine = True
        routineTimer.add(1.000000)
        # update component parameters for each repeat
        dots.setDir(dotdir)
        dots.refreshDots()
        # keep track of which components have finished
        movingdotsComponents = [dots, Moving_Fix]
        for thisComponent in movingdotsComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        movingdotsClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "movingdots"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = movingdotsClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=movingdotsClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *dots* updates
            if dots.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                dots.frameNStart = frameN  # exact frame index
                dots.tStart = t  # local t and not account for scr refresh
                dots.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(dots, 'tStartRefresh')  # time at next scr refresh
                dots.setAutoDraw(True)
            if dots.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > dots.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    dots.tStop = t  # not accounting for scr refresh
                    dots.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(dots, 'tStopRefresh')  # time at next scr refresh
                    dots.setAutoDraw(False)
            
            # *Moving_Fix* updates
            if Moving_Fix.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Moving_Fix.frameNStart = frameN  # exact frame index
                Moving_Fix.tStart = t  # local t and not account for scr refresh
                Moving_Fix.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Moving_Fix, 'tStartRefresh')  # time at next scr refresh
                Moving_Fix.setAutoDraw(True)
            if Moving_Fix.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > Moving_Fix.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    Moving_Fix.tStop = t  # not accounting for scr refresh
                    Moving_Fix.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(Moving_Fix, 'tStopRefresh')  # time at next scr refresh
                    Moving_Fix.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in movingdotsComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "movingdots"-------
        for thisComponent in movingdotsComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        Moving_Loop.addData('Moving_Fix.started', Moving_Fix.tStartRefresh)
        Moving_Loop.addData('Moving_Fix.stopped', Moving_Fix.tStopRefresh)
        thisExp.nextEntry()
        
    # completed moving_rep repeats of 'Moving_Loop'
    
    # get names of stimulus parameters
    if Moving_Loop.trialList in ([], [None], None):
        params = []
    else:
        params = Moving_Loop.trialList[0].keys()
    # save data for this loop
    Moving_Loop.saveAsExcel(filename + '.xlsx', sheetName='Moving_Loop',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # set up handler to look after randomisation of conditions etc
    Flicker_Loop = data.TrialHandler(nReps=flicker_rep, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='Flicker_Loop')
    thisExp.addLoop(Flicker_Loop)  # add the loop to the experiment
    thisFlicker_Loop = Flicker_Loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisFlicker_Loop.rgb)
    if thisFlicker_Loop != None:
        for paramName in thisFlicker_Loop:
            exec('{} = thisFlicker_Loop[paramName]'.format(paramName))
    
    for thisFlicker_Loop in Flicker_Loop:
        currentLoop = Flicker_Loop
        # abbreviate parameter names if possible (e.g. rgb = thisFlicker_Loop.rgb)
        if thisFlicker_Loop != None:
            for paramName in thisFlicker_Loop:
                exec('{} = thisFlicker_Loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "flickeringdots"-------
        continueRoutine = True
        routineTimer.add(15.000000)
        # update component parameters for each repeat
        # keep track of which components have finished
        flickeringdotsComponents = [dots_2, Flicker_Fix]
        for thisComponent in flickeringdotsComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        flickeringdotsClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "flickeringdots"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = flickeringdotsClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=flickeringdotsClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *dots_2* updates
            if dots_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                dots_2.frameNStart = frameN  # exact frame index
                dots_2.tStart = t  # local t and not account for scr refresh
                dots_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(dots_2, 'tStartRefresh')  # time at next scr refresh
                dots_2.setAutoDraw(True)
            if dots_2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > dots_2.tStartRefresh + 15.0-frameTolerance:
                    # keep track of stop time/frame for later
                    dots_2.tStop = t  # not accounting for scr refresh
                    dots_2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(dots_2, 'tStopRefresh')  # time at next scr refresh
                    dots_2.setAutoDraw(False)
            
            # *Flicker_Fix* updates
            if Flicker_Fix.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Flicker_Fix.frameNStart = frameN  # exact frame index
                Flicker_Fix.tStart = t  # local t and not account for scr refresh
                Flicker_Fix.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Flicker_Fix, 'tStartRefresh')  # time at next scr refresh
                Flicker_Fix.setAutoDraw(True)
            if Flicker_Fix.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > Flicker_Fix.tStartRefresh + 15.0-frameTolerance:
                    # keep track of stop time/frame for later
                    Flicker_Fix.tStop = t  # not accounting for scr refresh
                    Flicker_Fix.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(Flicker_Fix, 'tStopRefresh')  # time at next scr refresh
                    Flicker_Fix.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in flickeringdotsComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "flickeringdots"-------
        for thisComponent in flickeringdotsComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        Flicker_Loop.addData('Flicker_Fix.started', Flicker_Fix.tStartRefresh)
        Flicker_Loop.addData('Flicker_Fix.stopped', Flicker_Fix.tStopRefresh)
        thisExp.nextEntry()
        
    # completed flicker_rep repeats of 'Flicker_Loop'
    
    # get names of stimulus parameters
    if Flicker_Loop.trialList in ([], [None], None):
        params = []
    else:
        params = Flicker_Loop.trialList[0].keys()
    # save data for this loop
    Flicker_Loop.saveAsExcel(filename + '.xlsx', sheetName='Flicker_Loop',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
# completed 1.0 repeats of 'Block_Loop'


# ------Prepare to start Routine "justfixation"-------
continueRoutine = True
routineTimer.add(15.000000)
# update component parameters for each repeat
# keep track of which components have finished
justfixationComponents = [fixation_cross]
for thisComponent in justfixationComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
justfixationClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "justfixation"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = justfixationClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=justfixationClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *fixation_cross* updates
    if fixation_cross.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        fixation_cross.frameNStart = frameN  # exact frame index
        fixation_cross.tStart = t  # local t and not account for scr refresh
        fixation_cross.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(fixation_cross, 'tStartRefresh')  # time at next scr refresh
        fixation_cross.setAutoDraw(True)
    if fixation_cross.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > fixation_cross.tStartRefresh + 15.0-frameTolerance:
            # keep track of stop time/frame for later
            fixation_cross.tStop = t  # not accounting for scr refresh
            fixation_cross.frameNStop = frameN  # exact frame index
            win.timeOnFlip(fixation_cross, 'tStopRefresh')  # time at next scr refresh
            fixation_cross.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in justfixationComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "justfixation"-------
for thisComponent in justfixationComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('fixation_cross.started', fixation_cross.tStartRefresh)
thisExp.addData('fixation_cross.stopped', fixation_cross.tStopRefresh)

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
